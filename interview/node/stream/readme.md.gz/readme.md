Stream   Buffer

node API -> node building c++ -> v8 + libuv   string -> buffer -> stream
QPS  每秒查询率 QPS是对一个特定的查询服务器在规定时间内所处理流量多少的数量标准


编写一个脚本，接收要压缩的文件地址作为参数，压缩一下

buffer -> node